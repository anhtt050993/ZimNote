#!/bin/bash
echo " May chu can co 2 IP phuc vu 2 Instance Postfix"
sleep 2
read -p "Nhap dia chi IP thu 1: " ip1
read -p "Nhap dia chi IP thu 2: " ip2
#nhap thong tin database quan ly truy cap Postfix
read -p "Nhap database quan ly emd(postfix): " emddb
read -p "Nhap user database quan ly emd(postfix): " emduser
read -p "Nhap password cua user tren quan ly emd(postfix): " emdpassword
read -p "Nhap dia chi IP mariadbserver(localhost thi nhap localhost): " emdhost
hostname=`cat /etc/hostname`
#remove postfix2
#yum remove postfix -y
#rm -rf `find / -name postfix*`
#install postfix3
sudo yum -y install epel-release yum-utils
yum --nogpg install -y https://mirror.ghettoforge.org/distributions/gf/gf-release-latest.gf.el7.noarch.rpm
sudo yum-config-manager --enable gf-plus
#yum clean all
#yum makecache
yum install -y postfix3 postfix3-ldap postfix3-mysql postfix3-utils
rpm -qi postfix3
systemctl start postfix
systemctl enable postfix
systemctl status postfix
#config postfix main.cf
cp -vp /etc/postfix/main.cf /etc/postfix/main.cf.ori
sed -i 's/#inet_interfaces = all/inet_interfaces = all/g' /etc/postfix/main.cf
sed -i 's/inet_interfaces = localhost/#inet_interfaces = localhost/g' /etc/postfix/main.cf
sed -i 's/#inet_protocols = ipv4/inet_protocols = ipv4/g' /etc/postfix/main.cf
echo "#config work with OpenDkim
smtpd_milters           = inet:127.0.0.1:8891
non_smtpd_milters       = \$smtpd_milters
milter_default_action   = accept
milter_protocol         = 2

#add-config
smtp_tls_security_level = may
smtp_tls_loglevel = 2
message_size_limit = 10485760

smtpd_recipient_restrictions =
   reject_non_fqdn_recipient, reject_unknown_recipient_domain,
   check_recipient_access proxy:mysql:/etc/postfix/mysql-recipient-access.cf

smtpd_client_restrictions =
   check_client_access proxy:mysql:/etc/postfix/mysql-client-access.cf,
   reject

smtpd_sender_restrictions =
   check_sender_access proxy:mysql:/etc/postfix/mysql-sender-access.cf,
   reject

sender_dependent_default_transport_maps = proxy:mysql:/etc/postfix/mysql-sender-transport.cf" >>/etc/postfix/main.cf
cat <<EOF | tee /etc/postfix/mysql-recipient-access.cf
user = $emduser
password = $emdpassword
dbname = $emddb
hosts = $emdhost
query = select (CASE COUNT(ra.access) WHEN 0 THEN "OK" ELSE ra.access END) as access FROM restrict_addresses ra WHERE ra.recipient="%s"
EOF
cat <<EOF | tee /etc/postfix/mysql-client-access.cf
user = $emduser
password = $emdpassword
dbname = $emddb
hosts = $emdhost
query = SELECT \`access\` FROM \`client_accesses\` WHERE \`client_ip\`='%s' LIMIT 1
EOF
cat <<EOF | tee /etc/postfix/mysql-sender-access.cf
user = $emduser
password = $emdpassword
dbname = $emddb
hosts = $emdhost
query = SELECT \`access\` FROM \`sender_accesses\` WHERE \`sender\`='%s' LIMIT 1
EOF
cat <<EOF | tee /etc/postfix/mysql-sender-transport.cf
user = $emduser
password = $emdpassword
dbname = $emddb
hosts = $emdhost
query = SELECT \`transport\` FROM \`sender_transports\` WHERE \`sender\`='%s' GROUP BY \`sender\`
EOF
cat <<EOF | tee /etc/postfix/mysql-relay-domain.cf
user = $emduser
password = $emdpassword
dbname = $emddb
hosts = $emdhost
query = SELECT '%s' as \`domain\`
EOF
# config postfix master.cf
cp -vp /etc/postfix/master.cf /etc/postfix/master.cf.ori
sed -i '12a\#  -o smtpd_upstream_proxy_protocol=haproxy \
#  -o smtpd_upstream_proxy_timeout=5s' /etc/postfix/master.cf
echo "out-one     unix  -       -       n       -       -       smtp
  -o smtp_bind_address=$ip1
  -o inet_interfaces=$ip1
  -o myhostname=$hostname
  -o smtp_helo_name=$hostname
  -o syslog_name=smtp-out-one
out-two     unix  -       -       n       -       -       smtp
  -o smtp_bind_address=$ip2
  -o inet_interfaces=$ip2
  -o myhostname=$hostname
  -o smtp_helo_name=$hostname
  -o syslog_name=smtp-out-two" >> /etc/postfix/master.cf
systemctl restart postfix
#Install OpenDkim
yum install -y opendkim opendkim-tools opendbx-mysql mysql-libs
cp /etc/opendkim.conf /etc/opendkim.conf.ori
#sed -i 's/Mode    v/Mode    sv/g' /etc/opendkim.conf
sed -i '39s/v/sv/' /etc/opendkim.conf
#sed -i 's/Umask   002/Umask   022/g' /etc/opendkim.conf
sed -i '60s/002/022/' /etc/opendkim.conf
sed -i '83s/^/#/' /etc/opendkim.conf
echo "AutoRestart             Yes
AutoRestartRate         10/1h
TemporaryDirectory      /var/tmp
Canonicalization        relaxed/simple
KeyTable     dsn:mysql://$emduser:$emdpassword@$emdhost/$emddb/table=domains?keycol=id?datacol=name,dkim_selector,dkim_private_key
SigningTable dsn:mysql://$emduser:$emdpassword@$emdhost/$emddb/table=domains?keycol=name?datacol=id
ExternalIgnoreList      refile:/etc/opendkim/TrustedHosts
InternalHosts           refile:/etc/opendkim/TrustedHosts" >> /etc/opendkim.conf
systemctl start opendkim
systemctl enable opendkim
