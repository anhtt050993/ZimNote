#!/bin/bash
echo "Ban can chuan bi code cua emd-admin-master vao thu muc /tmp/emd-admin-master
Vui long hoan thanh buoc nay truoc khi bat dau script"
sleep 3
#Cung cap thong tin 
read -p "Nhap ten trang web quan tri emd: " emdhost
read -p "Nhap database muon tao cho emd: " emd_db
read -p "Nhap user(mariadb) muon tao de quan ly database emd: " emd_user
echo "password default cho user tren la 'password'"
sleep 2
yum install vim -y
#create mariadb repo
cat <<EOF | sudo tee /etc/yum.repos.d/mariadb.repo
[mariadb]
name = MariaDB
baseurl = http://yum.mariadb.org/10.6/centos7-amd64
gpgkey=https://yum.mariadb.org/RPM-GPG-KEY-MariaDB
gpgcheck=1
EOF
#create nginx repo
cat <<EOF | tee /etc/yum.repos.d/nginx.repo
[nginx]
name=nginx repo
baseurl=https://nginx.org/packages/centos/\$releasever/\$basearch/
gpgcheck=0
enabled=1
EOF
#check nginx install or not
if [ -x "$(command -v nginx)" ]; then
    echo "Nginx đã được cài đặt."
#    exit 0
else
    echo "Nginx chưa được cài đặt. Đang tiến hành cài đặt..."
yum install nginx -y
fi
# create config file for emd-admin
cat <<EOF | tee /etc/nginx/conf.d/emd-admin.conf
server {
	listen 80;
#	listen [::]:80;
		server_name $emdhost;					#Tên web truy cập vào LVREL'
		root /usr/share/nginx/emd-admin-master/public;		#Move code vào thư mục /usr/share/nginx

	add_header X-Frame-Options "SAMEORIGIN";
	add_header X-Content-Type-Options "nosniff";

	index index.php;

	charset utf-8;

	location / {
		try_files \$uri \$uri/ /index.php?\$query_string;
	}

	location = /favicon.ico { access_log off; log_not_found off; }
	location = /robots.txt  { access_log off; log_not_found off; }

	error_page 404 /index.php;

	location ~ \.php$ {
		fastcgi_pass unix:/var/run/php-fpm/php-fpm.sock;			#Tạo folder này để php-fpm work
		fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
		include fastcgi_params;
	}

	location ~ /\.(?!well-known).* {
		deny all;
	}
}
EOF
mkdir -p /var/run/php
mv /tmp/emd-admin-master /usr/share/nginx/
chown -R nginx:nginx /usr/share/nginx/emd-admin-master
# install mariabd and create database
yum install -y  mariadb-server mariadb
systemctl start mariadb
mysql -u root -e "CREATE DATABASE $emd_db;"
mysql -u root <<EOF
CREATE USER '$emd_user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON $emd_db.* TO '$emd_user'@'localhost';
FLUSH PRIVILEGES;
EOF
# install php
sudo yum install -y http://rpms.remirepo.net/enterprise/remi-release-7.rpm
yum install yum-utils -y
sudo yum-config-manager --disable remi-php54
sudo yum-config-manager --enable remi-php80
yum install -y php php-fpm php-{zip,ctype,curl,dom,fileinfo,filter,hash,mbstring,openssl,pcre,pdo,session,tokenizer,xml,mysqlnd}
# edit php work with nginx
chown -R nginx:nginx /var/lib/php
cp -vp /etc/php-fpm.d/www.conf /etc/php-fpm.d/www.conf.ori
sed -i 's/user = apache/user = nginx/g' /etc/php-fpm.d/www.conf
sed -i 's/group = apache/group = nginx/g' /etc/php-fpm.d/www.conf
sed -i 's/listen = 127.0.0.1:9000/listen = \/var\/run\/php-fpm\/php-fpm.sock/g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.owner = nobody/listen.owner = nginx/g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.group = nobody/listen.group = nginx/g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.mode = 0660/listen.mode = 0660/g' /etc/php-fpm.d/www.conf
cd /usr/share/nginx/emd-admin-master/public
cat <<EOF | tee test.php
<?php

phpinfo();

?>
EOF
systemctl restart php-fpm nginx mariadb
# install composer
curl -sS https://getcomposer.org/installer -o composer-setup.php
sudo php composer-setup.php --install-dir=/usr/bin --filename=composer
# dung composer cai dat cac depend
cd /usr/share/nginx/emd-admin-master
composer install --optimize-autoloader --prefer-dist --no-dev
cp .env.example .env
sed -i "s/Laravel/\"Email Mass Delivery\"/g" .env
sed -i "s/http:\/\/localhost/http:\/\/$emdhost/g" .env
sed -i "s/laravel/$emd_db/g" .env
sed -i "s/root/$emd_user/g" .env
sed -i "s/DB_PASSWORD=/DB_PASSWORD= password/g" .env
cd /usr/share/nginx/emd-admin-master
php artisan key:generate
php artisan config:cache
php artisan migrate:refresh
echo "cd vao thu muc /usr/share/nginx/emd-admin-master va go lenh sau de tao user quan tri: php artisan make:filament-user "
sleep 5
systemctl enable nginx
systemctl enable mariadb
systemctl enable php-fpm
