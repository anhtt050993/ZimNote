#!/bin/bash
# input information
read -p "Nhap ten database muon tao cho TIG stack: " tigdb
read -p "Nhap ten user quan ly database vua tao: " tiguser
read -p "Nhap password cua user vua tao: " tiguserpassword
read -p "Nhap dia chi IP cua TIG server: " tigip
#make a repo for influxdb
cat << EOF | tee /etc/yum.repos.d/influxdb.repo
[influxdb]
name = InfluxDB Repository - RHEL \$releasever
baseurl = https://repos.influxdata.com/rhel/\$releasever/\$basearch/stable
enabled = 1
gpgcheck = 0
EOF
#make a repo for grafana
cat << EOF | tee /etc/yum.repos.d/grafana.repo
[grafana]
name=grafana
baseurl=https://packages.grafana.com/oss/rpm
repo_gpgcheck=1
enabled=1
gpgcheck=1
gpgkey=https://packages.grafana.com/gpg.key
sslverify=1
sslcacert=/etc/pki/tls/certs/ca-bundle.crt
EOF
yum install influxdb -y
yum install grafana -y
yum install telegraf -y
systemctl start influxdb
#create database influxdb
influx -execute "CREATE DATABASE $tigdb"
influx -execute "CREATE USER $tiguser WITH PASSWORD '$tiguserpassword'"
influx -execute "GRANT ALL ON $tigdb TO $tiguser"
#config telegraf
cp -vp /etc/telegraf/telegraf.conf /etc/telegraf/telegraf.conf.ori
sed -i '1352s/#//' /etc/telegraf/telegraf.conf
sed -i '1359s/#//g' /etc/telegraf/telegraf.conf
sed -i "1359s/127.0.0.1/$tigip/" /etc/telegraf/telegraf.conf
sed -i '1363s/#//g' /etc/telegraf/telegraf.conf
sed -i "1363s/telegraf/$tigdb/" /etc/telegraf/telegraf.conf
sed -i '1396s/#//g' /etc/telegraf/telegraf.conf
sed -i "1396s/telegraf/$tiguser/" /etc/telegraf/telegraf.conf
sed -i '1397s/#//g' /etc/telegraf/telegraf.conf
sed -i "1397s/metricsmetricsmetricsmetrics/$tiguserpassword/" /etc/telegraf/telegraf.conf
#config grafana
cp -vp /etc/grafana/grafana.ini /etc/grafana/grafana.ini.ori
sed -i 's/;admin_user = admin/admin_user = admin/g' /etc/grafana/grafana.ini
sed -i 's/;admin_password = admin/admin_password = password/g' /etc/grafana/grafana.ini
systemctl start telegraf
systemctl start grafana-server
echo "Dang nhap Grafana tai dia chi IP TIG-server:3000"
echo "Tai khoan quan tri la admin/password"
sleep 5
echo "Hoan thien cau hinh theo huong dan o link sau:
https://bizflycloud.vn/tin-tuc/huong-dan-cai-dat-tig-stack-tren-centos-7-20210429160403812.htm "
