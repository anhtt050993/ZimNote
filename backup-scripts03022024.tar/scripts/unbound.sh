#!/bin/bash
yum install unbound -y
cp /etc/unbound/unbound.conf /etc/unbound/unbound.conf.original
sed -i '46s/#//' /etc/unbound/unbound.conf
sed -i 's/# do-ip4/do-ip4/g' /etc/unbound/unbound.conf
sed -i 's/# do-udp: yes/do-udp: yes/g' /etc/unbound/unbound.conf
sed -i 's/# do-tcp: yes/do-tcp: yes/g' /etc/unbound/unbound.conf
sed -i 's/# logfile: ""/logfile: \/var\/log\/unbound.log/g' /etc/unbound/unbound.conf
sed -i 's/trust-anchor-signaling: yes/trust-anchor-signaling: no/g' /etc/unbound/unbound.conf
sed -i 's/# hide-identity: no/hide-identity: yes/g' /etc/unbound/unbound.conf
sed -i 's/# hide-version: no/hide-version: yes/g' /etc/unbound/unbound.conf
sed -i 's/# access-control: 0.0.0.0\/0 refuse/access-control: 0.0.0.0\/0 allow/g' /etc/unbound/unbound.conf
sed -i '830s/#//' /etc/unbound/unbound.conf
sed -i '830a\       name: "."' /etc/unbound/unbound.conf
sed -i '831a\       forward-addr: 8.8.8.8' /etc/unbound/unbound.conf
sed -i '832a\       forward-addr: 8.8.4.4' /etc/unbound/unbound.conf
sed -i 's/server-key-file/#server-key-file/g' /etc/unbound/unbound.conf
sed -i 's/server-cert-file/#server-cert-file/g' /etc/unbound/unbound.conf
sed -i 's/control-key-file/#control-key-file/g' /etc/unbound/unbound.conf
sed -i 's/control-cert-file/#control-cert-file/g' /etc/unbound/unbound.conf
touch /var/log/unbound.log
chown -R unbound:unbound /var/log/unbound.log
systemctl restart unbound
systemctl status unbound -l
