#!/bin/bash
for i in `cat /tmp/domain.txt`; do
a=`dig mx $i`
echo $a >> /tmp/mx.txt
done
less /tmp/mx.txt | cut -d "X" -f 3 | cut -d ";" -f 1 | cut -d " " -f 3 > /tmp/result.txt
for i1 in `cat /tmp/result.txt`; do
nmap -sV $i1 -p 143 -Pn
done
