#!/bin/bash
read -p "Nhap dia chi ip postfix xac thuc: " postfixxacthuc
read -p "Nhap dia chi ip postfix khog xac thuc: " postfixkoxacthuc
read -p "Nhap hostname emd web: " hostemd
read -p "Nhap hostname mautic web: " hostmautic
read -p "Nhap dia chi ip emd web: " ipemd
read -p "Nhap dia chi ip mauticweb: " ipmautic
yum -y install haproxy
hacontent="frontend ft_smtp
bind $postfixxacthuc:25
mode tcp
no option http-server-close
timeout client 1m
log global
option tcplog
maxconn 4096
default_backend bk_postfix

backend bk_postfix
mode tcp
no option http-server-close
log global
option tcplog
timeout server 1m
timeout connect 30s
balance roundrobin
server postfix-host1 $postfixxacthuc:25 send-proxy

frontend ft_smtps
bind $postfixkoxacthuc:25
mode tcp
no option http-server-close
timeout client 1m
log global
option tcplog
maxconn 4096
default_backend bk_postfixs

backend bk_postfixs
mode tcp
no option http-server-close
log global
option tcplog
timeout server 1m
timeout connect 30s
balance roundrobin
server postfix-host1 $postfixkoxacthuc:25 send-proxy


frontend http-in
  bind *:80
  acl is_emd-poc hdr(host) -i $hostemd
  acl is_mautic-poc hdr(host) -i $hostmautic
  use_backend emd-poc-backend if is_emd-poc
  use_backend mautic-poc-backend if is_mautic-poc

backend emd-poc-backend
  balance roundrobin
  server emd-poc $ipemd:80 check

backend mautic-poc-backend
  balance roundrobin
  server mautic-poc $ipmautic:80 check"
echo "$hacontent" >> /etc/haproxy/haproxy.cfg
systemctl restart haproxy
systemctl enable haproxy
